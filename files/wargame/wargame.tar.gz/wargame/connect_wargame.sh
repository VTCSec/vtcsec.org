#!/bin/bash
################################################################################
# Cyber Security Club @ Virginia Tech
# Wargame VPN connection script
#
# This script connects to the wargame VPN; it requires OpenVPN and must be run
# as root.
################################################################################

# Path to OpenVPN exeecutable
OPENVPN=/usr/sbin/openvpn

#-----------------------------------------------------------

if [ "$(id -u)" != "0" ]; then
    echo "This script must be run as root"  1>&2
    exit 1
fi

if [ ! -f $OPENVPN ]; then
    echo "Cannot find OpenVPN. Is it installed?" 1>&2
    exit 1
fi

do_connect() {
    echo 
    echo "Initiating VPN Connection..."
    echo "When prompted for a username and password, you may enter anything."
    echo 
    $OPENVPN --config wargame.conf
}

echo "------------------------------------------------------------"
echo "Cyber Security Club @ Virginia Tech - Wargame"
echo "------------------------------------------------------------"
echo
echo "WARNING: This network is dangerous. Do not connect your "
echo "personal computer or a production machine to this network."
echo
echo "Do you wish to continue? (Choose a number)"
YES="Yes, I understand the risks."
NO="No, do not connect me to the wargame network."
select yn in "$YES" "$NO"; do
    case $yn in
        $YES ) do_connect; break;;
        $NO ) exit;;
    esac
done
